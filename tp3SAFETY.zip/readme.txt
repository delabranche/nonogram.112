Farid Khuri-Makdisi
andrewid: fkhurima
TP: nonogram.112

###################
Project Description:
###################

nonogram.112 is an app in which you can play/create nonograms and color nonograms. It includes a uniqueness checker and a variant of the puzzle I created called "nonorikabe".

###################
Running nonogram.112:
###################

The user must run tp3.py, and cmu_112_graphics must be in the same folder as tp3.py. Note that this version of cmu_112_graphics is different from the one on the 15112 website! 

###################
Modules/Libraries:
###################

Modules used: math, string, copy, random, itertools, cmu_112_graphics
All built into python 3, no need to download anything except for cmu_112_graphics as mentioned above.

